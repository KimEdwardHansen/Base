﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTOs;
using Data;
using Core;
using Infrastructure;

namespace AppServices
{
    public class City : ICity
    {
        private IMap _mapper;
        
        public City(IMap mapper)
        {
            _mapper = mapper;
           
        }
       


        public CityDTO LookupCity(string Name)
        {
            CityDTO c = new CityDTO();
            Core.City city = new Core.City();
            ContextFactory cf = new ContextFactory();
            using(Context ctx = cf.CreateContext())
            {
                city = ctx.Cities.Where(x => x.Name.Trim().ToLower() == Name.Trim().ToLower()).FirstOrDefault();
            }

            c = _mapper.DoMap<Core.City, CityDTO>(city, c);
            return c;
        }
    }
}
