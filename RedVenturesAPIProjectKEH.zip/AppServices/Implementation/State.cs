﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using Data;
using Infrastructure;
using DTOs;

namespace AppServices
{
    public class State : IState
    {
        private IMap _mapper;
        

        public State(IMap mapper)
        {
            _mapper = mapper;
           
        }


        public IEnumerable<DTOs.CityDTO> GetCitiesPerState(string lookupState)
        {
            List<CityDTO> retList = new List<CityDTO>();

            List<Core.City> cities = new List<Core.City>();

            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {
                var states = ctx.States.Where(x => x.Abbreviation.Trim().ToLower() == lookupState.Trim().ToLower() || x.Name.Trim().ToLower() == lookupState.Trim().ToLower()).ToList();
        
                foreach(Core.State s in states)
                {
                    foreach(Core.City c in s.Cities)
                    {
                        CityDTO cityDTO = new CityDTO();
                        cityDTO = _mapper.DoMap<Core.City, CityDTO>(c, cityDTO);
                        retList.Add(cityDTO);
                    }
                }

            }

            return retList.AsEnumerable();

        }

        

        public StateDTO LookupState(string Abbreviation)
        {
            Core.State s = new Core.State();
            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {
                s = ctx.States.Where(x => x.Abbreviation.Trim().ToLower() == Abbreviation.Trim().ToLower()).FirstOrDefault();
                if(s==null)
                {
                    s = ctx.States.Where(x => x.Name.Trim().ToLower() == Abbreviation.Trim().ToLower()).FirstOrDefault();
                }
            }

            StateDTO stateDTO = new StateDTO();
            stateDTO = _mapper.DoMap<Core.State, StateDTO>(s, stateDTO);

            return stateDTO;
        }
    }
}
