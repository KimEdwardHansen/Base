﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using Data;
using Infrastructure;
using DTOs;

namespace AppServices
{

    public class User : IUser
    {
        private IMap _mapper;
        public User(IMap mapper)
        {
            _mapper = mapper;
        }
        public bool AuthenticateUser(string firstName, string lastName)
        {
            bool retval = false;
            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {
                retval = ctx.Users.Where(x => x.FirstName.Trim().ToLower() == firstName.Trim().ToLower()
                                      && x.LastName.Trim().ToLower() == lastName.Trim().ToLower()).Count() == 1 ? true : false;
            }

            return retval;
        }

        public UserDTO LookupUser(string firstName, string lastName)
        {
            Core.User u = new Core.User();

            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {
                u = ctx.Users.Where(x => x.FirstName.ToLower() == firstName.Trim().ToLower()
                                    && x.LastName.ToLower() == lastName.Trim().ToLower()
                    ).FirstOrDefault();
            }

            UserDTO userDTO = new UserDTO();
            userDTO = _mapper.DoMap<Core.User, UserDTO>(u, userDTO);

            return userDTO;
        }
    }

}