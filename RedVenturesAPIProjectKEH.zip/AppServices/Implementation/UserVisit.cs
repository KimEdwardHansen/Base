﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using Data;
using DTOs;
using Infrastructure;

namespace AppServices
{
    public class UserVisit : IUserVisit
    {
        private IMap _mapper;
        public UserVisit(IMap mapper)
        {
            _mapper = mapper;
          
        }
        
        public bool AddUserVisit(UserVisitDTO userVisitDTO)
        {
            bool retval = true;
            try
            {
                Core.UserVisit uv = new Core.UserVisit();
               
                ContextFactory cf = new ContextFactory();
                using (Context ctx = cf.CreateContext())
                {
                    uv.City = ctx.Cities.Where(x => x.Name.Trim().ToLower() == userVisitDTO.City.Name.Trim().ToLower()).FirstOrDefault();
                    uv.State = ctx.States.Where(x => x.Name.Trim().ToLower() == userVisitDTO.State.Name.Trim().ToLower()).FirstOrDefault();
                    uv.User = ctx.Users.Where(x => x.FirstName.Trim().ToLower() == userVisitDTO.User.FirstName.Trim().ToLower()
                                            && x.LastName.Trim().ToLower() == userVisitDTO.User.LastName.Trim().ToLower()).FirstOrDefault();
                    
                    //Add to Database
                    ctx.UserVisits.Add(uv);
                    ctx.Entry(uv).State = System.Data.Entity.EntityState.Added;
                    ctx.SaveChanges();
                }
            }
            catch(Exception ex)
            {
                retval = false;
            }

            return retval;
        }

        public bool DeleteUserVisit(UserVisitDTO userVisitDTO)
        {
            bool retval = false;
            Core.UserVisit uv = new Core.UserVisit();
 

            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {

                uv = ctx.UserVisits.Where(x => x.User.FirstName.Trim().ToLower() == userVisitDTO.User.FirstName.Trim().ToLower()
                                          && x.User.LastName.Trim().ToLower() == userVisitDTO.User.LastName.Trim().ToLower()
                                          && x.City.Name.Trim().ToLower() == userVisitDTO.City.Name.Trim().ToLower()
                                          && x.State.Abbreviation.Trim().ToLower() == userVisitDTO.State.Abbreviation.Trim().ToLower()
                                    ).FirstOrDefault();

                    if (uv != null)
                    {
                        //Delete UserVisit
                        ctx.UserVisits.Remove(uv);
                        ctx.Entry(uv).State = System.Data.Entity.EntityState.Deleted;
                        ctx.SaveChanges();

                        retval = true;
                    }
                }
            

            return retval;
        }


        public IEnumerable<DTOs.UserVisitDTO> GetUserVisitsByUser(DTOs.UserDTO userDTO)
        {
            List<UserVisitDTO> retList = new List<UserVisitDTO>();
            Core.User u = new Core.User();
            u = _mapper.DoMap<UserDTO, Core.User>(userDTO, u);
            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {
                var userVisits = ctx.UserVisits.Where(x => x.User.LastName.ToLower() == u.LastName.ToLower() && x.User.FirstName.ToLower() == u.FirstName.ToLower()).ToList();
        
                foreach(var item in userVisits)
                {
                    UserVisitDTO uvDTO = new UserVisitDTO();
                    uvDTO = _mapper.DoMap<Core.UserVisit, UserVisitDTO>(item, uvDTO);                  
                    retList.Add(uvDTO);
                }
            }

            return retList.AsEnumerable();
       }

        public IEnumerable<DTOs.CityDTO> ReturnAllCitiesVisited(DTOs.UserDTO user)
        {
            List<CityDTO> retList = new List<CityDTO>();

            ContextFactory cf = new ContextFactory();
            using (Context ctx = cf.CreateContext())
            {

                var userVisits = ctx.UserVisits.Where(x => x.User.LastName.Trim().ToLower() == user.LastName.Trim().ToLower() && x.User.FirstName.Trim().ToLower() == user.FirstName.Trim().ToLower()).ToList();

                foreach (Core.UserVisit item in userVisits)
                {
                    CityDTO cityDTO = new CityDTO();
                    cityDTO = _mapper.DoMap<Core.City, DTOs.CityDTO>(item.City, cityDTO);
                    retList.Add(cityDTO);
                }
            }
            return retList.AsEnumerable();
        }

        public IEnumerable<DTOs.StateDTO> ReturnAllStatesVisited(DTOs.UserDTO user)
        {
            List<StateDTO> retList = new List<StateDTO>();
            
             ContextFactory cf = new ContextFactory();

            using (Context ctx = cf.CreateContext())
            {
                Core.User u = new Core.User();
                u = ctx.Users.Where(x => x.FirstName.Trim().ToLower() == user.FirstName.Trim().ToLower()
                                    && x.LastName.Trim().ToLower() == user.LastName.Trim().ToLower()).FirstOrDefault();

                List<Core.UserVisit> userVisits = u.UserVisits.ToList();

                  foreach (var item in userVisits)
                  {
                      StateDTO stateDTO = new StateDTO();
                      stateDTO = _mapper.DoMap<Core.State, StateDTO>(item.State, stateDTO);
                      retList.Add(stateDTO);
                  }
            }

            return retList.AsEnumerable();
        }
    }
}
