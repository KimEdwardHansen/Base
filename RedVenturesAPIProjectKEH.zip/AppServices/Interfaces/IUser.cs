﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTOs;

namespace AppServices
{
    public interface IUser
    {
        bool AuthenticateUser(string firstName, string lastName);

        UserDTO LookupUser(string firstName, string lastName);
    }
}
