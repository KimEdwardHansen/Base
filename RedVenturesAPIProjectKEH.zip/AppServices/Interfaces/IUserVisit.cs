﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using DTOs;

namespace AppServices
{
    public interface IUserVisit
    {

        bool AddUserVisit(UserVisitDTO userVisitDTO);
        bool DeleteUserVisit(UserVisitDTO userVisitDTO);

        IEnumerable<UserVisitDTO> GetUserVisitsByUser(UserDTO userDTO);
        IEnumerable<CityDTO> ReturnAllCitiesVisited(UserDTO user);

        IEnumerable<StateDTO> ReturnAllStatesVisited(UserDTO user);
    }
}
