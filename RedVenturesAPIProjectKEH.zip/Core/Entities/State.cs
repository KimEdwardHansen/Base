﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class State
    {

        public State()
        {
            DateAdded = DateTime.Now;
            DateTimeAdded = DateTime.Now;
            LastUpdated = DateTime.Now;
        }

        public int StateId { get; set; }
        public string Name { get; set; }
        public string Abbreviation { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime DateTimeAdded { get; set; }
        public DateTime LastUpdated { get; set; }

        public virtual ICollection<City> Cities { get; set; }
        public virtual ICollection<UserVisit> UserVisits { get; set; }

    }
}
