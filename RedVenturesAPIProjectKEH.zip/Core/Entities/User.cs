﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Core
{
    public class User
    {
        public User()
        {
            DateAdded = DateTime.Now;
            DateTimeAdded = DateTime.Now;
            LastUpdated = DateTime.Now;
        }

        public int UserId { get; set; }
        public string FirstName { get; set; }
        public string LastName { get; set; }
        public DateTime DateAdded { get; set; }
        public DateTime DateTimeAdded { get; set; }
        public DateTime LastUpdated { get; set; }

        public virtual ICollection<UserVisit> UserVisits { get; set; }
    }
}
