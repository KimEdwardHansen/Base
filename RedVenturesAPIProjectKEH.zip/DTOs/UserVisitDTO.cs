﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace DTOs
{
    public class UserVisitDTO
    {
        public UserDTO User { get; set; }
        public CityDTO City { get; set; }
        public StateDTO State { get; set; }
    
    }
}
