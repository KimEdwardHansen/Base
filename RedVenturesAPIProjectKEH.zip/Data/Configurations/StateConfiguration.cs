﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;
using Core;


namespace Data
{
    public class StateConfiguration : EntityTypeConfiguration<State>
    {
        public StateConfiguration()
        {
            ToTable("States");
            Property(e => e.StateId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            Property(e => e.DateAdded).HasColumnType("date");
            HasMany(e => e.Cities).WithRequired(c => c.State);
            HasMany(e => e.UserVisits).WithRequired(u => u.State);
        }

    }
}
