﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Data.Entity.ModelConfiguration;
using System.Data.Entity;
using System.ComponentModel.DataAnnotations.Schema;
using Core;

namespace Data
{
    public class UserConfiguration: EntityTypeConfiguration<User>
    {
        public UserConfiguration()
        {
            ToTable("Users");
            Property(e => e.UserId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasMany(e => e.UserVisits).WithRequired(x => x.User);
        }
    }
}
