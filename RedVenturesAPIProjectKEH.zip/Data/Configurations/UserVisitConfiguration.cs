﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using Core;
using System.Data.Entity;
using System.Data.Entity.ModelConfiguration;
using System.ComponentModel.DataAnnotations.Schema;

namespace Data
{
    public class UserVisitConfiguration : EntityTypeConfiguration<UserVisit>
    {
        public UserVisitConfiguration()
        {
            ToTable("UserVisits");
            Property(e => e.UserVisitId).HasDatabaseGeneratedOption(DatabaseGeneratedOption.Identity);
            HasRequired(e => e.User).WithMany(x => x.UserVisits);
            HasRequired(e => e.City).WithMany(x => x.UserVisits);
            HasRequired(e => e.State).WithMany(x => x.UserVisits);
            
        }
    }
}
