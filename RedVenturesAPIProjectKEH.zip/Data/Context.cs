﻿using System;
using System.Data;
using System.Data.Entity;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations.Schema;
using Core;


namespace Data
{
    public class Context : DbContext
    {
        public Context(string connString):base(connString)
        {

        }

        public virtual DbSet<User> Users { get; set; }
        public virtual DbSet<City> Cities { get; set; }
        public virtual DbSet<State> States { get; set; }
        public virtual DbSet<UserVisit> UserVisits { get; set; }

        protected override void OnModelCreating(DbModelBuilder modelBuilder)
        {
            modelBuilder.Configurations.Add<User>(new UserConfiguration());
            modelBuilder.Configurations.Add<UserVisit>(new UserVisitConfiguration());
            modelBuilder.Configurations.Add<City>(new CityConfiguration());
            modelBuilder.Configurations.Add<State>(new StateConfiguration());


            modelBuilder.Entity<User>().Property(u => u.UserId);
            modelBuilder.Entity<UserVisit>().Property(v => v.UserVisitId);
            modelBuilder.Entity<City>().Property(c => c.CityId);
            modelBuilder.Entity<State>().Property(s => s.StateId);

            base.OnModelCreating(modelBuilder);
        }
    }
}

