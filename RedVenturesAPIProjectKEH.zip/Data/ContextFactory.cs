﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Configuration;

namespace Data
{
    public class ContextFactory : IContextFactory
    {
        private string _connString;
        public ContextFactory()
        {
            _connString = System.Configuration.ConfigurationManager.ConnectionStrings["RedVenturesDB"].ConnectionString.ToString();
        }

        public Context CreateContext()
        {
            Context ctx = new Context(_connString);
            return ctx;
        }

    }
}
