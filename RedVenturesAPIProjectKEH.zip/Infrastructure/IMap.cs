﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace Infrastructure
{
    public interface IMap
    {
        U DoMap<T,U>(T src, U dest);
    
    }
}
