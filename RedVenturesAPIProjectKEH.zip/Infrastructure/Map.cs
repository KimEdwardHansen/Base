﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using AutoMapper;

namespace Infrastructure
{
    public class Map : IMap
    {
        public U DoMap<T, U>(T src, U dest)
        {
            var config = new MapperConfiguration(cfg =>
            {
                cfg.CreateMap<T, U>();
                cfg.CreateMissingTypeMaps = true;
            });

            IMapper mapper = config.CreateMapper();
            return mapper.Map<T, U>(src);

        }
    }
}
