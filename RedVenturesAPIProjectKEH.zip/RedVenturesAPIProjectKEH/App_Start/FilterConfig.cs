﻿using System.Web;
using System.Web.Mvc;
using RedVenturesAPIProjectKEH.Filters;
using System.Web.Http.Filters;

namespace RedVenturesAPIProjectKEH
{
    public class FilterConfig
    {
        public static void RegisterGlobalFilters(GlobalFilterCollection filters)
        {
            filters.Add(new HandleErrorAttribute());

           // filters.Add(new ValidationFilterAttribute());
        }

        public static void RegisterHttpFilters(HttpFilterCollection filters)
        { 
            filters.Add(new ValidationFilterAttribute());
        
        }
    }
}
