﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Http;
using System.Web.Http;
using Infrastructure;
using AppServices;
using DTOs;

namespace RedVenturesAPIProjectKEH.Controllers
{
    [RoutePrefix("api/RV")]
    public class RedVenturesController : ApiController
    {

        private IMap _mapper;
        private ICity _city;
        private IState _state;
        private IUser _user;
        private IUserVisit _userVisit;
        public RedVenturesController(IMap mapper, ICity city, IState state, IUser user, IUserVisit userVisit)
        {
            _mapper = mapper;
            _city = city;
            _state = state;
            _user = user;
            _userVisit = userVisit;
        }

        [HttpGet]
        [Route("state/{state}/cities")]
        public IEnumerable<Models.City> GetAllCitiesForState([FromUri]string state)
        {
            List<Models.City> cities = new List<Models.City>();

            var results = _state.GetCitiesPerState(state);
    
            foreach(var item in results)
            {
                Models.City c = new Models.City() { CityName = item.Name };
                cities.Add(c);
            }

            return cities.AsEnumerable();
           
        }

        [HttpPost]
        [Route("user/{firstname}/{lastname}/visits")]
        public bool AddUserVisit([FromUri]string firstname, [FromUri]string lastname, [FromBody] Models.Visit visit)
        {
            bool retval = false;

            if (_user.AuthenticateUser(firstname, lastname))
            {
                UserDTO userDTO = new UserDTO(); // { FirstName = firstname.Trim(), LastName = lastname.Trim() };
                userDTO = _user.LookupUser(firstname, lastname);

                CityDTO cityDTO = new CityDTO();
                cityDTO = _city.LookupCity(visit.City);

                StateDTO stateDTO = new StateDTO();
                stateDTO = _state.LookupState(visit.State);

                UserVisitDTO uv = new UserVisitDTO() { User = userDTO, City = cityDTO, State = stateDTO };
                retval = _userVisit.AddUserVisit(uv);
            }

            return retval;
        }


        [HttpDelete]
        [Route("user/{firstname}/{lastname}/visit/{city}/{state}")]
        public bool RemoveUserVisit([FromUri] string firstname, [FromUri] string lastname, [FromUri] string city, [FromUri] string state)
        {
            bool retval = false;
            UserVisitDTO uv = new UserVisitDTO();
            uv.User = _user.LookupUser(firstname, lastname);
            uv.City = _city.LookupCity(city);
            uv.State = _state.LookupState(state);

            retval = _userVisit.DeleteUserVisit(uv);

            return retval;
        }

        [HttpGet]
        [Route("user/{firstname}/{lastname}/visits")]
        public IEnumerable<Models.Visit> ListAllVisits([FromUri] string firstname, [FromUri]string lastname)
        {
            List<Models.Visit> uservisits = new List<Models.Visit>();

            if (_user.AuthenticateUser(firstname, lastname))
            {
                UserDTO userDTO = new UserDTO();
                userDTO = _user.LookupUser(firstname, lastname);
                var results = _userVisit.GetUserVisitsByUser(userDTO);

                foreach (var item in results.ToList())
                {
                    Models.Visit v = new Models.Visit();
                    v.City = item.City.Name;
                    v.State = item.State.Abbreviation;

                    uservisits.Add(v);
                }
            }
            return uservisits.AsEnumerable();
        }
         

        [HttpGet]
        [Route("user/{firstname}/{lastname}/visits/states")]
        public IEnumerable<Models.State> ListAllStatesVisited([FromUri] string firstname, [FromUri]string lastname)    
        {
            List<Models.State> states = new List<Models.State>();

            if (_user.AuthenticateUser(firstname, lastname))
            {
                UserDTO userDTO = new UserDTO();
                userDTO = _user.LookupUser(firstname, lastname);

                var results = _userVisit.ReturnAllStatesVisited(userDTO);
             //   var results = _state.ReturnAllStatesVisited(userDTO);
                foreach (var item in results.ToList())
                {
                    Models.State s = new Models.State();
                    s = _mapper.DoMap<StateDTO, Models.State>(item, s);
                    states.Add(s);
                }
            }

            return states.AsEnumerable();
        }
    }
}