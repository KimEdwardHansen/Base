﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Runtime.Serialization;

namespace RedVenturesAPIProjectKEH.Models
{
    [DataContract]
    public class Visit
    {
        [DataMember]
        public string City { get; set; }

        [DataMember]
        public string State { get; set; }
    }
}