﻿CREATE TABLE [dbo].[Cities]
(
	[CityId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] VARCHAR(100) NULL, 
    [Status] VARCHAR(50) NULL, 
    [Latitude] DECIMAL(18, 9) NULL, 
    [Longitude] DECIMAL(18, 9) NULL, 
    [DateAdded] DATE NULL, 
    [DateTimeAdded] DATETIME2 NULL, 
    [LastUpdated] DATETIME2 NULL, 
    [State_StateId] INT NULL, 
    CONSTRAINT [FK_Cities_States] FOREIGN KEY ([State_StateId]) REFERENCES [States]([StateId])
)
