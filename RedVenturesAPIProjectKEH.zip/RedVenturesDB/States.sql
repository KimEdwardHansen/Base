﻿CREATE TABLE [dbo].[States]
(
	[StateId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [Name] VARCHAR(100) NULL, 
    [Abbreviation] VARCHAR(50) NULL, 
    [DateAdded] DATE NULL, 
    [DateTimeAdded] DATETIME2 NULL, 
    [LastUpdated] DATETIME2 NULL
)
