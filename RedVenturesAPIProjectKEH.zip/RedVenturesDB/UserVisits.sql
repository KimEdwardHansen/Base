﻿CREATE TABLE [dbo].[UserVisits]
(
	[UserVisitId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [User_UserId] INT NULL, 
    [City_CityId] INT NULL, 
    [State_StateId] INT NULL, 
    CONSTRAINT [FK_UserVisits_Users] FOREIGN KEY ([User_UserId]) REFERENCES [Users]([UserId]), 
    CONSTRAINT [FK_UserVisits_Cities] FOREIGN KEY ([City_CityId]) REFERENCES [Cities]([CityId]), 
    CONSTRAINT [FK_UserVisits_States] FOREIGN KEY ([State_StateId]) REFERENCES [States]([StateId])
)
