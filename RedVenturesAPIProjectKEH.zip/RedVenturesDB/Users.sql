﻿CREATE TABLE [dbo].[Users]
(
	[UserId] INT NOT NULL PRIMARY KEY IDENTITY, 
    [FirstName] VARCHAR(100) NULL, 
    [LastName] VARCHAR(100) NULL, 
    [DateAdded] DATE NULL, 
    [DateTimeAdded] DATETIME2 NULL, 
    [LastUpdated] DATETIME2 NULL
)
