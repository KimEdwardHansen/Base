﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Data;
using Core;
using Infrastructure;
using System.Data;
using System.Data.Entity;
using System.Linq;
using AppServices;
using DTOs;
using System.Collections.Generic;

namespace UnitTestProject1
{
    [TestClass]
    public class AppServicesTests
    {
        [TestMethod]
        public void TestLookupCity()
        {
            Map mapper = new Map();
            AppServices.City appCity = new AppServices.City(mapper);
            CityDTO city = appCity.LookupCity("Sedona");

            Assert.IsTrue(city.Name == "Sedona" && city.Latitude == Decimal.Parse("34.865979000"));

        }
    
        [TestMethod]
        public void TestLookupState()
        {
            Map mapper = new Map();
            AppServices.State appState = new AppServices.State(mapper);
            StateDTO state = appState.LookupState("AZ");

            Assert.IsTrue(state.Name == "Arizona" && state.Abbreviation == "AZ");

        }


        [TestMethod]
        public void TestLookupStateName()
        {
            Map mapper = new Map();
            AppServices.State appState = new AppServices.State(mapper);
            StateDTO state = appState.LookupState("Arizona");

            Assert.IsTrue(state.Name == "Arizona" && state.Abbreviation == "AZ");

        }

        [TestMethod]
        public void TestGetCitiesByState()
        {
            Map mapper = new Map();
            AppServices.State state = new AppServices.State(mapper);
            var results = state.GetCitiesPerState("AZ");

            Assert.IsInstanceOfType(results, typeof(IEnumerable<CityDTO>));
            Assert.IsTrue(results.Count() > 0);

        }

        [TestMethod]
        public void TestAuthenticateUser()
        {
            Map mapper = new Map();
            AppServices.User user = new AppServices.User(mapper);
            bool testval = user.AuthenticateUser("Jim", "Smith");
            Assert.IsTrue(testval);
        }
    
        [TestMethod]
        public void TestLookupUser()
        {
            Map mapper = new Map();
            AppServices.User user = new AppServices.User(mapper);
           var testval = user.LookupUser("Jim", "Smith");
           Assert.IsInstanceOfType(testval, typeof(UserDTO));
           Assert.IsTrue(testval.FirstName == "Jim" && testval.LastName == "Smith");
        }

        [TestMethod]
        public void TestAddUserVisit()
        {
            Map mapper = new Map();
            AppServices.UserVisit uv = new AppServices.UserVisit(mapper);

            UserDTO u = new UserDTO() { FirstName = "Jim", LastName = "Smith" };
            CityDTO c = new CityDTO() { Name = "Montgomery" };
            StateDTO s = new StateDTO() { Abbreviation = "AL", Name = "Alabama" };
            UserVisitDTO userVisitDTO = new UserVisitDTO() { User = u, City = c, State = s};
            
            
            var testval = uv.AddUserVisit(userVisitDTO);
            Assert.IsTrue(testval);
            
        }

        [TestMethod]
        public void TestDeleteUserVisit()
        {
            Map mapper = new Map();
            AppServices.UserVisit uv = new AppServices.UserVisit(mapper);

            UserDTO u = new UserDTO() { FirstName = "Jim", LastName = "Smith" };
            CityDTO c = new CityDTO() { Name = "Montgomery" };
            StateDTO s = new StateDTO() { Abbreviation = "AL", Name = "Alabama" };
            UserVisitDTO userVisitDTO = new UserVisitDTO() { User = u, City = c, State = s };


            var testval = uv.DeleteUserVisit(userVisitDTO);
            Assert.IsTrue(testval);
        }

        [TestMethod]
        public void TestGetUserVisits()
        {
            Map mapper = new Map();
            AppServices.UserVisit uv = new AppServices.UserVisit(mapper);
            UserDTO user = new UserDTO(){FirstName="Jim", LastName="Smith"};
            var userVisits = uv.GetUserVisitsByUser(user);
            Assert.IsTrue(userVisits.Count() > 0);
        }
        
        [TestMethod]
        public void TestGetCitiesVisited()
        {
            Map mapper = new Map();
            AppServices.UserVisit uv = new AppServices.UserVisit(mapper);
            UserDTO user = new UserDTO() { FirstName = "Jim", LastName = "Smith" };
            var testval = uv.ReturnAllCitiesVisited(user);

            Assert.IsTrue(testval.Count() > 0);
            Assert.IsTrue(testval.Where(x => x.Name == "Sedona").Count() == 1);
        }
      
        [TestMethod]
        public void TestGetStatesVisited()
        {
            Map mapper = new Map();
            AppServices.UserVisit uv = new AppServices.UserVisit(mapper);
            UserDTO user = new UserDTO() { FirstName = "Jim", LastName = "Smith" };
            var testval = uv.ReturnAllStatesVisited(user);

            Assert.IsTrue(testval.Count() > 0);
        
        }
        
    }
}
