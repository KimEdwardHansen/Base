﻿using System;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using Data;
using Core;
using System.Data;
using System.Data.Entity;
using System.Linq;

namespace UnitTestProject1
{
    [TestClass]
    public class DataContextTests
    {
        [TestMethod]
        public void TestContextFactoryReturnsContext()
        {

            ContextFactory ctxFactory = new ContextFactory();
            var ctx = ctxFactory.CreateContext();
            Assert.IsTrue(ctx.GetType() == typeof(Context));
            
        }

        [TestMethod]
        public void InsertUser()
        {
            ContextFactory ctxFactory = new ContextFactory();
            var ctx = ctxFactory.CreateContext();

            User user = new User() {FirstName = "Test", LastName = "TestLastname" };
            ctx.Users.Add(user);
            ctx.Entry(user).State = System.Data.Entity.EntityState.Added;
            int retval = ctx.SaveChanges();

            Assert.IsTrue(retval > 0);
        }

        [TestMethod]
        public void InsertState()
        {
            ContextFactory ctxFactory = new ContextFactory();
            var ctx = ctxFactory.CreateContext();

            State state = new State();
            state.Name = "Alabama";
            state.Abbreviation = "AL";

            ctx.States.Add(state);
            ctx.Entry(state).State = System.Data.Entity.EntityState.Added;
            int retval = ctx.SaveChanges();

            Assert.IsTrue(retval > 0);
        }

        [TestMethod]
        public void InsertCity()
        {
            ContextFactory ctxFactory = new ContextFactory();
            Context ctx = ctxFactory.CreateContext();
            int retval = 0;

            var state = ctx.States.Where(x => x.Abbreviation == "AL").FirstOrDefault();
            if (state != null)
            {
                City city = new City() { Name = "Birmingham", Latitude = (decimal)-81.44, Longitude = (decimal)80.44, Status = "verified" };
                state.Cities.Add(city);
                ctx.Entry(state).State = System.Data.Entity.EntityState.Modified;
                retval = ctx.SaveChanges();
                       
            }

            var cityadded = ctx.Cities.Where(x => x.Name == "Birmingham").FirstOrDefault();
            
            Assert.IsTrue(retval > 0 && cityadded.Name == "Birmingham");
        }

        [TestMethod]
        public void InsertCityWithoutStateFails()
        {
            bool retval = false;
            try
            {
                ContextFactory ctxFactory = new ContextFactory();
                Context ctx = ctxFactory.CreateContext();
               

                City city = new City() { Name = "Birmingham", Latitude = (decimal)-81.44, Longitude = (decimal)80.44, Status = "verified" };
                ctx.Cities.Add(city);
                ctx.Entry(city).State = System.Data.Entity.EntityState.Added;
                ctx.SaveChanges();
            }
            catch(Exception ex)
            {
              retval =true;
            }

            Assert.IsTrue(retval);
        }
        [TestMethod]
        public void InsertUserVisit()
        {
            ContextFactory ctxFactory = new ContextFactory();
            Context ctx = ctxFactory.CreateContext();
            int retval = 0;
        
            //get objects
            var oUser = ctx.Users.Where(x => x.FirstName == "Test").FirstOrDefault();
            var oState = ctx.States.Where(x => x.Abbreviation == "AL").FirstOrDefault();
            var oCity = oState.Cities.First();

            var userVisit = new UserVisit();
            userVisit.User = oUser;
            userVisit.State = oState;
            userVisit.City = oCity;

            ctx.Entry(userVisit).State = EntityState.Added;
            retval = ctx.SaveChanges();

            Assert.IsTrue(retval > 0);

        }
        
        [TestMethod]
        public void DeleteUserVisit()
        {
            ContextFactory ctxFactory = new ContextFactory();
            Context ctx = ctxFactory.CreateContext();
            int retval = 0;

            UserVisit uv = ctx.UserVisits.Where(x => x.City.Name == "Birmingham" && x.State.Abbreviation == "AL").FirstOrDefault();
            if(uv != null)
            {
                ctx.UserVisits.Remove(uv);
                ctx.Entry(uv).State = EntityState.Deleted;
                retval = ctx.SaveChanges();
            }

            Assert.IsTrue(retval > 0);
        }

        [TestMethod]
        public void InsertUserVisitFailsWithNull()
        {
            ContextFactory ctxFactory = new ContextFactory();
            Context ctx = ctxFactory.CreateContext();
            bool retval = false;

            //get objects
            User oUser = null; //ctx.Users.Where(x => x.FirstName == "Test").FirstOrDefault();
            var oState = ctx.States.Where(x => x.Abbreviation == "AL").FirstOrDefault();
            var oCity = oState.Cities.First();

            var userVisit = new UserVisit();
            userVisit.User = oUser;
            userVisit.State = oState;
            userVisit.City = oCity;
            try
            {
                ctx.Entry(userVisit).State = EntityState.Added;
                ctx.SaveChanges();
            }
            catch(Exception ex)
            {
                retval = true;
            }
            
            Assert.IsTrue(retval);

        }
        

    }
}
